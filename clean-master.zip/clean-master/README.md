### Clean Theme

![Alt text](screen.png)

